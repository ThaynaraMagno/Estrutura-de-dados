# -*- coding: utf-8 -*-
from jogo_velha import JogoVelha
    
jogo = JogoVelha()

jogo.start()

jogo.wait_quit_event()

